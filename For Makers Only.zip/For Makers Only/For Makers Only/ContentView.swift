//
//  ContentView.swift
//  For Makers Only
//
//  Created by Tagart,Will on 12/9/23.
//

import SwiftUI

extension Color {
    init(hex:UInt) {
        self.init(
            .sRGB,
            red: Double((hex & 0xFF0000) >> 16) / 255.0,
            green: Double((hex & 0x00FF00) >> 8) / 255.0,
            blue: Double((hex & 0xFF0000) >> 16) / 255.0,
            opacity: 1.0
        )
    }
}

struct ContentView: View {
    var body: some View {
        ZStack{
            Color(hex: 0xEDE7DF)
                .ignoresSafeArea()
            
            VStack {
                Text("WHEN LIFE GIVES YOU WAX, WICK IT")
                
                NavigationLink(destination: Page2View()) {
                    Text("NEXT")
                        .padding()
                        .foregroundColor(.black)
                        .cornerRadius(8)
                }
                .padding()
            }
        }
    }
}

struct Page2View: View {
    var body: some View {
        VStack{
            Text("Page2")
        }
    }
}

struct StateView: View {
    let stateOptions = ["Select State", "AZ", "CA", "NV"]
    
    @State private var selectedStateIndex = 0
    
    var body: some View {
        VStack {
            Text("Products by State")
                .font(.title)
                .padding()
            
            Picker("Select a State", selection: $selectedStateIndex) {
                ForEach(0..<stateOptions.count, id: \.self) { index in
                    Text(self.stateOptions[index])
                }
            }
            .pickerStyle(SegmentedPickerStyle())
            .padding(.top, 20)
            
            if selectedStateIndex != 0 {
                NavigationLink(destination: destinationViewForSelectedState()) {
                    Text("Go to Product Page")
                        .foregroundColor(.white)
                        .padding()
                        .background(Color.green)
                        .cornerRadius(8)
                }
                .padding(.top, 20)
            } else {
                Text("Please select a state first.")
                    .foregroundColor(.red)
                    .padding(.top, 20)
            }
        }
    }
    
    // Helper function to determine the destination view based on the selected state
    func destinationViewForSelectedState() -> some View {
        switch selectedStateIndex {
        case 1:
            return AnyView(AZProductsView())
        case 2:
            return AnyView(CAProductsView())
        case 3:
            return AnyView(NVProductsView())
        default:
            return AnyView(EmptyView())
        }
    }
}

// Sample views (replace with your actual views)
struct AZProductsView: View {
    var body: some View {
        Text("Arizona Products")
    }
}

struct CAProductsView: View {
    var body: some View {
        Text("California Products")
    }
}

struct NVProductsView: View {
    var body: some View {
        Text("Nevada Products")
    }
}

#Preview{
    ContentView()
}




struct ProductsView: View {
    @State private var searchText = ""
    let allProducts = (1..<7).map { "Product \($0)" }
    
    var filteredProducts: [String] {
        if searchText.isEmpty {
            return allProducts
        } else {
            return allProducts.filter { $0.localizedCaseInsensitiveContains(searchText) }
        }
    }
    
    var body: some View {
        VStack {
            SearchBar(text: $searchText)
            
            Text("Full Product List")
                .font(.largeTitle)
                .foregroundColor(.black)
                .padding()
            
            let gridItems = [GridItem(.flexible(), spacing: 10), GridItem(.flexible(), spacing: 10)] // Fixed gridItems declaration
            
            ScrollView {
                LazyVGrid(columns: gridItems, spacing: 10) {
                    ForEach(filteredProducts, id: \.self) { product in
                        NavigationLink(destination: getPageViewForProduct(product)) {
                            VStack {
                                Spacer()
                                Image("image\(product.last!)")
                                    .resizable()
                                    .aspectRatio(contentMode: .fill)
                                    .frame(width: 150, height: 150)
                                
                                Text(product)
                                    .font(.caption)
                                    .foregroundColor(.black)
                            }
                        }
                    }
                }
                .padding()
            }
        }
    }
    
    func getPageViewForProduct(_ product: String) -> some View {
        guard let productNumber = Int(String(product.last ?? "a")) else {
            return AnyView(EmptyView())
        }
 
        switch productNumber {
        case 1:
            return AnyView(Product1View())
        case 2:
            return AnyView(Product2View()
        default:
            return AnyView(EmptyView())
        }
    }
}

struct Product1View: View {
    var body: some View {
        Text("Product 1 Details")
    }
}

struct Product2View: View {
    var body: some View {
        Text("Product 2 Details")
    }
}

//                           struct SearchBar: view{
//                               @Binding var text: String
//                           
//                               var body: some View {
//                                   HStack {
//                                       TextField("Search...", text: $text)
//                                           .padding(8)
//                                           .background(Color(.systemGray6))
//                                           .cornerRadius(10)
//                                           .padding([.leading, .trailing], 10)
//                                   }
//                                   .padding(.top, 10)
//                                   .padding(.bottom, 10)
