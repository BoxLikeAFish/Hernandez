//
//  For_Makers_OnlyApp.swift
//  For Makers Only
//
//  Created by Tagart,Will on 12/9/23.
//

import SwiftUI

@main
struct For_Makers_OnlyApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
