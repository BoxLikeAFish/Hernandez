//
//  candlesApp.swift
//  candles
//
//  Created by xcodeday on 12/8/23.
//

import SwiftUI

@main
struct candlesApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
